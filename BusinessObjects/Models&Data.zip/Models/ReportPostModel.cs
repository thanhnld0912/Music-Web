﻿public class PostReportModel
{
    public int UserId { get; set; }
    public string Reason { get; set; }
}